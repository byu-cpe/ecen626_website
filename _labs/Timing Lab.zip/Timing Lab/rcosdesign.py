import numpy as np

def srrcDesign ( SPS, beta, span ):

	invalidParameter = False

	if (SPS <= 1):
		print('srrcDesign.py: SPS must be greater than 1')
		invalidParameter = True

	if ((int(SPS) - SPS) > 1e-10):
		print('srrcDesign.py: SPS must be an integer')
		invalidParameter = True

	if (span < 1):
		print('srrcDesign.py: span must be greater than or equal to 1')
		invalidParameter = True

	if ((int(span) - span) > 1e-10):
		print('srrcDesign.py: span must be an integer')
		invalidParameter = True

	if (beta < 0):
		print('srrcDesign.py: beta must be greater than or equal to 0')
		invalidParameter = True

	# check to see if a bad parameter was passed in
	if (invalidParameter):
		# return empty filter weights
		return []

	else: # parameters valid, proceed with design
		# build the time indexing
		nList = np.arange(-span*SPS,(span*SPS)+1)

		# pre-allocate memory for weights
		weights = np.zeros(len(nList))

		# compute the weights on a sample by sample basis
		for index in range(len(nList)):

			# select the time index
			n = nList[index]

			# design equations
			if (n == 0):
				weights[index] = (1/np.sqrt(SPS))*((1-beta) + (4*beta/np.pi))
			elif (np.abs(n*4*beta) == SPS):
				weights[index] = (beta/np.sqrt(2*SPS))*( (1+(2/np.pi))*np.sin(np.pi/(4*beta)) + (1-(2/np.pi))*np.cos(np.pi/(4*beta)) )
			else:
				weights[index] = (1/np.sqrt(SPS))*( (np.sin(np.pi*n*(1-beta)/SPS)) + (4*beta*n/SPS)*(np.cos(np.pi*n*(1+beta)/SPS)) ) / ( (np.pi*n/SPS) * (1 - (4*beta*n/SPS)**2) )

		# scale the weights to 0 dB gain at f=0
		weights = weights/np.sqrt(SPS)

		return weights

if __name__ == '__main__':
    import matplotlib.pyplot as plt
    x = srrcDesign(4, 0.5, 6)
    plt.stem(x)
    plt.show()
    print(x.shape)